import FormData from 'form-data';
import { Platform } from 'react-native';

const OPENAI_API_KEY = process.env.EXPO_PUBLIC_OPENAI_API_KEY;
const WHISPER_API_URL = 'https://api.openai.com/v1/audio/transcriptions';

export async function transcribeAudio(audioUri: string): Promise<string> {
  try {
    if (!OPENAI_API_KEY) {
      throw new Error('OpenAI API anahtarı eksik. Lütfen .env dosyasını kontrol edin.');
    }

    if (!audioUri) {
      throw new Error('Ses dosyası bulunamadı.');
    }

    let audioBlob: Blob;
    
    try {
      if (Platform.OS === 'web') {
        if (audioUri.startsWith('blob:')) {
          const response = await fetch(audioUri);
          if (!response.ok) {
            throw new Error('Ses dosyası alınamadı');
          }
          audioBlob = await response.blob();
        } else {
          throw new Error('Geçersiz ses dosyası formatı');
        }
      } else {
        const response = await fetch(audioUri);
        if (!response.ok) {
          throw new Error('Ses dosyası alınamadı');
        }
        audioBlob = await response.blob();
      }

      if (!audioBlob || audioBlob.size === 0) {
        throw new Error('Ses dosyası boş');
      }

      if (audioBlob.size > 25 * 1024 * 1024) {
        throw new Error('Ses dosyası çok büyük. Maksimum 25MB desteklenir.');
      }
    } catch (error) {
      console.error('Ses dosyası işleme hatası:', error);
      throw new Error('Ses dosyası işlenirken bir hata oluştu');
    }

    const formData = new FormData();
    
    const audioFile = new File([audioBlob], 'audio.webm', { type: 'audio/webm' });
    formData.append('file', audioFile);
    formData.append('model', 'whisper-1');
    formData.append('language', 'tr');
    formData.append('response_format', 'json');

    try {
      const whisperResponse = await fetch(WHISPER_API_URL, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Accept': 'application/json',
        },
        body: formData,
      });

      if (!whisperResponse.ok) {
        const errorData = await whisperResponse.json().catch(() => ({}));
        const errorMessage = errorData.error?.message || 'Ses tanıma servisi şu anda kullanılamıyor.';
        console.error('Whisper API Error:', errorData);
        throw new Error(errorMessage);
      }

      const data = await whisperResponse.json();
      if (!data.text) {
        throw new Error('Ses tanıma sonucu alınamadı');
      }
      
      return data.text.trim();
    } catch (error) {
      console.error('API hatası:', error);
      throw error instanceof Error ? error : new Error('API isteği başarısız oldu');
    }
  } catch (error) {
    console.error('Transkripsiyon hatası:', error);
    throw error instanceof Error ? error : new Error('Beklenmeyen bir hata oluştu');
  }
}