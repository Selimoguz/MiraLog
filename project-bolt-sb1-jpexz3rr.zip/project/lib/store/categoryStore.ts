import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Category {
  id: number;
  name: string;
  description: string;
  icon: string;
  color: string;
  isStarred: boolean;
  lastUsed: string;
}

interface CategoryState {
  categories: Category[];
  isLoading: boolean;
  error: string | null;
  addCategory: (category: Omit<Category, 'id'>) => Promise<void>;
  updateCategory: (id: number, category: Partial<Category>) => Promise<void>;
  deleteCategory: (id: number) => Promise<void>;
  toggleStar: (id: number) => Promise<void>;
  getStarredCategories: () => Category[];
}

export const useCategoryStore = create<CategoryState>((set, get) => ({
  categories: [],
  isLoading: false,
  error: null,

  addCategory: async (category) => {
    set({ isLoading: true, error: null });
    try {
      const newCategory = {
        ...category,
        id: Date.now(),
      };
      const categories = [...get().categories, newCategory];
      await AsyncStorage.setItem('categories', JSON.stringify(categories));
      set({ categories, isLoading: false });
    } catch (error) {
      set({ error: 'Kategori eklenirken bir hata oluştu', isLoading: false });
    }
  },

  updateCategory: async (id, categoryUpdate) => {
    set({ isLoading: true, error: null });
    try {
      const categories = get().categories.map(category =>
        category.id === id ? { ...category, ...categoryUpdate } : category
      );
      await AsyncStorage.setItem('categories', JSON.stringify(categories));
      set({ categories, isLoading: false });
    } catch (error) {
      set({ error: 'Kategori güncellenirken bir hata oluştu', isLoading: false });
    }
  },

  deleteCategory: async (id) => {
    set({ isLoading: true, error: null });
    try {
      const categories = get().categories.filter(category => category.id !== id);
      await AsyncStorage.setItem('categories', JSON.stringify(categories));
      set({ categories, isLoading: false });
    } catch (error) {
      set({ error: 'Kategori silinirken bir hata oluştu', isLoading: false });
    }
  },

  toggleStar: async (id) => {
    set({ isLoading: true, error: null });
    try {
      const categories = get().categories.map(category =>
        category.id === id ? { ...category, isStarred: !category.isStarred } : category
      );
      await AsyncStorage.setItem('categories', JSON.stringify(categories));
      set({ categories, isLoading: false });
    } catch (error) {
      set({ error: 'Kategori yıldızlanırken bir hata oluştu', isLoading: false });
    }
  },

  getStarredCategories: () => {
    return get().categories.filter(category => category.isStarred);
  },
}));