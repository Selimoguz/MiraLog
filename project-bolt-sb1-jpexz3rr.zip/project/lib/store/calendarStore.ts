import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { format } from 'date-fns';

export interface CalendarEvent {
  id: string;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  noteId?: string;
  teamId?: string;
  attendees: string[];
  location?: string;
  isCompleted: boolean;
}

interface CalendarState {
  events: CalendarEvent[];
  isLoading: boolean;
  error: string | null;
  addEvent: (event: Omit<CalendarEvent, 'id'>) => Promise<void>;
  updateEvent: (id: string, event: Partial<CalendarEvent>) => Promise<void>;
  deleteEvent: (id: string) => Promise<void>;
  getEventsByDate: (date: Date) => CalendarEvent[];
  getEventsByNoteId: (noteId: string) => CalendarEvent[];
  syncWithGoogleCalendar: () => Promise<void>;
}

export const useCalendarStore = create<CalendarState>((set, get) => ({
  events: [],
  isLoading: false,
  error: null,

  addEvent: async (event) => {
    set({ isLoading: true, error: null });
    try {
      const newEvent: CalendarEvent = {
        ...event,
        id: Date.now().toString(),
      };
      const events = [...get().events, newEvent];
      await AsyncStorage.setItem('calendar_events', JSON.stringify(events));
      set({ events, isLoading: false });

      // TODO: Sync with Google Calendar
      await get().syncWithGoogleCalendar();
    } catch (error) {
      set({ error: 'Failed to add event', isLoading: false });
    }
  },

  updateEvent: async (id, eventUpdate) => {
    set({ isLoading: true, error: null });
    try {
      const events = get().events.map(event =>
        event.id === id ? { ...event, ...eventUpdate } : event
      );
      await AsyncStorage.setItem('calendar_events', JSON.stringify(events));
      set({ events, isLoading: false });

      // TODO: Sync with Google Calendar
      await get().syncWithGoogleCalendar();
    } catch (error) {
      set({ error: 'Failed to update event', isLoading: false });
    }
  },

  deleteEvent: async (id) => {
    set({ isLoading: true, error: null });
    try {
      const events = get().events.filter(event => event.id !== id);
      await AsyncStorage.setItem('calendar_events', JSON.stringify(events));
      set({ events, isLoading: false });

      // TODO: Sync with Google Calendar
      await get().syncWithGoogleCalendar();
    } catch (error) {
      set({ error: 'Failed to delete event', isLoading: false });
    }
  },

  getEventsByDate: (date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return get().events.filter(event => 
      event.startDate.startsWith(dateStr) || event.endDate.startsWith(dateStr)
    );
  },

  getEventsByNoteId: (noteId) => {
    return get().events.filter(event => event.noteId === noteId);
  },

  syncWithGoogleCalendar: async () => {
    set({ isLoading: true, error: null });
    try {
      // TODO: Implement Google Calendar sync
      // This will be implemented when we add Google Calendar integration
      set({ isLoading: false });
    } catch (error) {
      set({ error: 'Failed to sync with Google Calendar', isLoading: false });
    }
  },
}));