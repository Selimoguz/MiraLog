import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'admin' | 'member';
  avatar?: string;
}

export interface Team {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
  ownerId: string;
  members: TeamMember[];
}

interface TeamState {
  teams: Team[];
  currentTeam: Team | null;
  isLoading: boolean;
  error: string | null;
  createTeam: (team: Omit<Team, 'id' | 'createdAt'>) => Promise<void>;
  joinTeam: (teamId: string) => Promise<void>;
  leaveTeam: (teamId: string) => Promise<void>;
  switchTeam: (teamId: string) => Promise<void>;
  addMember: (teamId: string, member: Omit<TeamMember, 'id'>) => Promise<void>;
  removeMember: (teamId: string, memberId: string) => Promise<void>;
  updateMemberRole: (teamId: string, memberId: string, role: TeamMember['role']) => Promise<void>;
}

export const useTeamStore = create<TeamState>((set, get) => ({
  teams: [],
  currentTeam: null,
  isLoading: false,
  error: null,

  createTeam: async (team) => {
    set({ isLoading: true, error: null });
    try {
      const newTeam: Team = {
        ...team,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      };
      const teams = [...get().teams, newTeam];
      await AsyncStorage.setItem('teams', JSON.stringify(teams));
      set({ teams, currentTeam: newTeam, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to create team', isLoading: false });
    }
  },

  joinTeam: async (teamId) => {
    set({ isLoading: true, error: null });
    try {
      // Implement team joining logic
      set({ isLoading: false });
    } catch (error) {
      set({ error: 'Failed to join team', isLoading: false });
    }
  },

  leaveTeam: async (teamId) => {
    set({ isLoading: true, error: null });
    try {
      const teams = get().teams.filter(team => team.id !== teamId);
      await AsyncStorage.setItem('teams', JSON.stringify(teams));
      set({ 
        teams,
        currentTeam: teams.length > 0 ? teams[0] : null,
        isLoading: false 
      });
    } catch (error) {
      set({ error: 'Failed to leave team', isLoading: false });
    }
  },

  switchTeam: async (teamId) => {
    const team = get().teams.find(t => t.id === teamId);
    if (team) {
      set({ currentTeam: team });
      await AsyncStorage.setItem('currentTeamId', teamId);
    }
  },

  addMember: async (teamId, member) => {
    set({ isLoading: true, error: null });
    try {
      const teams = get().teams.map(team => {
        if (team.id === teamId) {
          return {
            ...team,
            members: [...team.members, { ...member, id: Date.now().toString() }]
          };
        }
        return team;
      });
      await AsyncStorage.setItem('teams', JSON.stringify(teams));
      set({ teams, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to add member', isLoading: false });
    }
  },

  removeMember: async (teamId, memberId) => {
    set({ isLoading: true, error: null });
    try {
      const teams = get().teams.map(team => {
        if (team.id === teamId) {
          return {
            ...team,
            members: team.members.filter(m => m.id !== memberId)
          };
        }
        return team;
      });
      await AsyncStorage.setItem('teams', JSON.stringify(teams));
      set({ teams, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to remove member', isLoading: false });
    }
  },

  updateMemberRole: async (teamId, memberId, role) => {
    set({ isLoading: true, error: null });
    try {
      const teams = get().teams.map(team => {
        if (team.id === teamId) {
          return {
            ...team,
            members: team.members.map(m => 
              m.id === memberId ? { ...m, role } : m
            )
          };
        }
        return team;
      });
      await AsyncStorage.setItem('teams', JSON.stringify(teams));
      set({ teams, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to update member role', isLoading: false });
    }
  },
}));