import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Note {
  id: number;
  title: string;
  summary: string;
  timestamp: string;
  date: string;
  category: string;
  color: string;
  isStarred: boolean;
  duration: string;
  participants?: string[];
  tags: string[];
}

const INITIAL_NOTES: Note[] = [
  {
    id: 1,
    title: 'Ekip Toplantısı - Ürün İncelemesi',
    timestamp: '14:30',
    date: '2024-03-20',
    summary: 'Q4 yol haritası ve özellik öncelikleri görüşüldü. Ekip, kullanıcı deneyimi iyileştirmeleri ve performans optimizasyonuna odaklanma konusunda anlaştı.',
    category: 'Toplantılar',
    color: '#0891b2',
    isStarred: true,
    duration: '45:22',
    participants: ['John Doe', 'Jane Smith', 'Mike Johnson'],
    tags: ['Q4', 'Product', 'UX'],
  },
  {
    id: 2,
    title: 'Proje Fikirleri',
    timestamp: '11:45',
    date: '2024-03-20',
    summary: 'Yeni mobil uygulama özellikleri için konseptler ve kullanıcı geri bildirimleri değerlendirildi. Öncelikli geliştirmeler belirlendi.',
    category: 'Fikirler',
    color: '#ca8a04',
    isStarred: false,
    duration: '15:30',
    tags: ['Mobile', 'Features', 'Feedback'],
  },
  {
    id: 3,
    title: 'Müşteri Görüşmesi Notları',
    timestamp: 'Dün',
    date: '2024-03-19',
    summary: 'Uygulama takvimi ve yeni özellik talepleri görüşüldü. Müşteri memnuniyeti ve beklentiler değerlendirildi.',
    category: 'Görüşmeler',
    color: '#059669',
    isStarred: true,
    duration: '32:15',
    participants: ['Client A', 'Sales Team'],
    tags: ['Client', 'Features', 'Timeline'],
  },
  {
    id: 4,
    title: 'Haftalık Sprint Planlaması',
    timestamp: 'Dün',
    date: '2024-03-19',
    summary: 'Gelecek sprint için görev dağılımı ve öncelikler belirlendi. Takım kapasitesi ve proje zaman çizelgesi gözden geçirildi.',
    category: 'Toplantılar',
    color: '#0891b2',
    isStarred: false,
    duration: '28:45',
    participants: ['Dev Team', 'Product Owner'],
    tags: ['Sprint', 'Planning'],
  },
  {
    id: 5,
    title: 'Yeni Özellik Konsepti',
    timestamp: '2 gün önce',
    date: '2024-03-18',
    summary: 'Sesli asistan entegrasyonu için teknik gereksinimler ve kullanıcı senaryoları oluşturuldu. API entegrasyonu planlandı.',
    category: 'Fikirler',
    color: '#ca8a04',
    isStarred: false,
    duration: '18:10',
    tags: ['AI', 'Integration', 'Technical'],
  },
];

interface NoteState {
  notes: Note[];
  isLoading: boolean;
  error: string | null;
  addNote: (note: Omit<Note, 'id'>) => Promise<void>;
  updateNote: (id: number, note: Partial<Note>) => Promise<void>;
  deleteNote: (id: number) => Promise<void>;
  toggleStar: (id: number) => Promise<void>;
  getNotesByCategory: (category: string) => Note[];
  getStarredNotes: () => Note[];
}

export const useNoteStore = create<NoteState>((set, get) => ({
  notes: INITIAL_NOTES,
  isLoading: false,
  error: null,

  addNote: async (note) => {
    set({ isLoading: true, error: null });
    try {
      const newNote = {
        ...note,
        id: Date.now(),
      };
      const notes = [...get().notes, newNote];
      await AsyncStorage.setItem('notes', JSON.stringify(notes));
      set({ notes, isLoading: false });
    } catch (error) {
      set({ error: 'Not eklenirken bir hata oluştu', isLoading: false });
    }
  },

  updateNote: async (id, noteUpdate) => {
    set({ isLoading: true, error: null });
    try {
      const notes = get().notes.map(note =>
        note.id === id ? { ...note, ...noteUpdate } : note
      );
      await AsyncStorage.setItem('notes', JSON.stringify(notes));
      set({ notes, isLoading: false });
    } catch (error) {
      set({ error: 'Not güncellenirken bir hata oluştu', isLoading: false });
    }
  },

  deleteNote: async (id) => {
    set({ isLoading: true, error: null });
    try {
      const notes = get().notes.filter(note => note.id !== id);
      await AsyncStorage.setItem('notes', JSON.stringify(notes));
      set({ notes, isLoading: false });
    } catch (error) {
      set({ error: 'Not silinirken bir hata oluştu', isLoading: false });
    }
  },

  toggleStar: async (id) => {
    set({ isLoading: true, error: null });
    try {
      const notes = get().notes.map(note =>
        note.id === id ? { ...note, isStarred: !note.isStarred } : note
      );
      await AsyncStorage.setItem('notes', JSON.stringify(notes));
      set({ notes, isLoading: false });
    } catch (error) {
      set({ error: 'Not yıldızlanırken bir hata oluştu', isLoading: false });
    }
  },

  getNotesByCategory: (category) => {
    return get().notes.filter(note => note.category === category);
  },

  getStarredNotes: () => {
    return get().notes.filter(note => note.isStarred);
  },
}));