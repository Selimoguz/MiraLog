import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface SettingsState {
  syncEnabled: boolean;
  notificationsEnabled: boolean;
  darkModeEnabled: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  isLoading: boolean;
  error: string | null;
  toggleSync: () => Promise<void>;
  toggleNotifications: () => Promise<void>;
  toggleDarkMode: () => Promise<void>;
  toggleSound: () => Promise<void>;
  toggleVibration: () => Promise<void>;
  loadSettings: () => Promise<void>;
}

export const useSettingsStore = create<SettingsState>((set, get) => ({
  syncEnabled: true,
  notificationsEnabled: true,
  darkModeEnabled: false,
  soundEnabled: true,
  vibrationEnabled: true,
  isLoading: false,
  error: null,

  toggleSync: async () => {
    try {
      const newValue = !get().syncEnabled;
      await AsyncStorage.setItem('settings_sync', JSON.stringify(newValue));
      set({ syncEnabled: newValue });
    } catch (error) {
      set({ error: 'Senkronizasyon ayarı değiştirilemedi' });
    }
  },

  toggleNotifications: async () => {
    try {
      const newValue = !get().notificationsEnabled;
      await AsyncStorage.setItem('settings_notifications', JSON.stringify(newValue));
      set({ notificationsEnabled: newValue });
    } catch (error) {
      set({ error: 'Bildirim ayarı değiştirilemedi' });
    }
  },

  toggleDarkMode: async () => {
    try {
      const newValue = !get().darkModeEnabled;
      await AsyncStorage.setItem('settings_darkMode', JSON.stringify(newValue));
      set({ darkModeEnabled: newValue });
    } catch (error) {
      set({ error: 'Karanlık mod ayarı değiştirilemedi' });
    }
  },

  toggleSound: async () => {
    try {
      const newValue = !get().soundEnabled;
      await AsyncStorage.setItem('settings_sound', JSON.stringify(newValue));
      set({ soundEnabled: newValue });
    } catch (error) {
      set({ error: 'Ses ayarı değiştirilemedi' });
    }
  },

  toggleVibration: async () => {
    try {
      const newValue = !get().vibrationEnabled;
      await AsyncStorage.setItem('settings_vibration', JSON.stringify(newValue));
      set({ vibrationEnabled: newValue });
    } catch (error) {
      set({ error: 'Titreşim ayarı değiştirilemedi' });
    }
  },

  loadSettings: async () => {
    set({ isLoading: true });
    try {
      const [sync, notifications, darkMode, sound, vibration] = await Promise.all([
        AsyncStorage.getItem('settings_sync'),
        AsyncStorage.getItem('settings_notifications'),
        AsyncStorage.getItem('settings_darkMode'),
        AsyncStorage.getItem('settings_sound'),
        AsyncStorage.getItem('settings_vibration'),
      ]);

      set({
        syncEnabled: sync ? JSON.parse(sync) : true,
        notificationsEnabled: notifications ? JSON.parse(notifications) : true,
        darkModeEnabled: darkMode ? JSON.parse(darkMode) : false,
        soundEnabled: sound ? JSON.parse(sound) : true,
        vibrationEnabled: vibration ? JSON.parse(vibration) : true,
      });
    } catch (error) {
      set({ error: 'Ayarlar yüklenemedi' });
    } finally {
      set({ isLoading: false });
    }
  },
}));