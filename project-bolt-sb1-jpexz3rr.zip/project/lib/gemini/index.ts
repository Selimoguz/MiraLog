const GEMINI_API_KEY = process.env.EXPO_PUBLIC_GEMINI_API_KEY;
const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';

interface GeminiResponse {
  summary: string;
}

export async function transcribeAndSummarize(audioText: string): Promise<GeminiResponse> {
  try {
    if (!GEMINI_API_KEY) {
      throw new Error('Gemini API anahtarı eksik. Lütfen .env dosyasını kontrol edin.');
    }

    if (!audioText || audioText.trim().length === 0) {
      throw new Error('Özetlenecek metin bulunamadı');
    }

    const summaryPrompt = `Aşağıdaki metni özetle ve ana noktaları çıkar. Özet kısa ve öz olmalı:\n\n${audioText}`;

    try {
      const response = await fetch(`${API_URL}?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: summaryPrompt
            }]
          }],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 1024,
          },
          safetySettings: [
            {
              category: "HARM_CATEGORY_HARASSMENT",
              threshold: "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
              category: "HARM_CATEGORY_HATE_SPEECH",
              threshold: "BLOCK_MEDIUM_AND_ABOVE"
            }
          ]
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('Gemini API Error:', errorData);
        throw new Error(errorData.error?.message || 'API yanıt vermedi');
      }

      const data = await response.json();
      if (!data.candidates?.[0]?.content?.parts?.[0]?.text) {
        throw new Error('Özet sonucu alınamadı');
      }

      return {
        summary: data.candidates[0].content.parts[0].text.trim()
      };
    } catch (error) {
      console.error('API hatası:', error);
      throw error instanceof Error ? error : new Error('API isteği başarısız oldu');
    }
  } catch (error) {
    console.error('Gemini işleme hatası:', error);
    throw error instanceof Error ? error : new Error('Beklenmeyen bir hata oluştu');
  }
}