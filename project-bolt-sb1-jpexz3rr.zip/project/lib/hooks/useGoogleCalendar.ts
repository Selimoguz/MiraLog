import { useState } from 'react';
import * as WebBrowser from 'expo-web-browser';
import * as AuthSession from 'expo-auth-session';
import AsyncStorage from '@react-native-async-storage/async-storage';

WebBrowser.maybeCompleteAuthSession();

const GOOGLE_CLIENT_ID = process.env.EXPO_PUBLIC_GOOGLE_CLIENT_ID;
const GOOGLE_REDIRECT_URI = AuthSession.makeRedirectUri();

interface UseGoogleCalendarReturn {
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  authenticate: () => Promise<void>;
  createEvent: (event: any) => Promise<void>;
  disconnect: () => Promise<void>;
}

export function useGoogleCalendar(): UseGoogleCalendarReturn {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const authenticate = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const config = {
        clientId: GOOGLE_CLIENT_ID,
        redirectUri: GOOGLE_REDIRECT_URI,
        scopes: ['https://www.googleapis.com/auth/calendar'],
      };

      const discovery = {
        authorizationEndpoint: 'https://accounts.google.com/o/oauth2/v2/auth',
        tokenEndpoint: 'https://oauth2.googleapis.com/token',
      };

      const request = await AuthSession.loadAsync(config, discovery);
      const result = await request.promptAsync();

      if (result.type === 'success') {
        await AsyncStorage.setItem('google_token', result.params.access_token);
        setIsAuthenticated(true);
      }
    } catch (err) {
      setError('Failed to authenticate with Google Calendar');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const createEvent = async (event: any) => {
    setIsLoading(true);
    setError(null);

    try {
      const token = await AsyncStorage.getItem('google_token');
      if (!token) {
        throw new Error('Not authenticated with Google Calendar');
      }

      const response = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(event),
      });

      if (!response.ok) {
        throw new Error('Failed to create event');
      }
    } catch (err) {
      setError('Failed to create event in Google Calendar');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const disconnect = async () => {
    setIsLoading(true);
    setError(null);

    try {
      await AsyncStorage.removeItem('google_token');
      setIsAuthenticated(false);
    } catch (err) {
      setError('Failed to disconnect from Google Calendar');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isAuthenticated,
    isLoading,
    error,
    authenticate,
    createEvent,
    disconnect,
  };
}