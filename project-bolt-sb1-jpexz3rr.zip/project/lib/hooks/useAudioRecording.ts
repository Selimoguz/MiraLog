import { useState, useEffect } from 'react';
import { Audio } from 'expo-av';
import { Platform } from 'react-native';

export function useAudioRecording() {
  const [recording, setRecording] = useState<Audio.Recording | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    return () => {
      if (recording) {
        recording.stopAndUnloadAsync();
      }
    };
  }, [recording]);

  async function startRecording() {
    try {
      setError(null);
      
      if (Platform.OS === 'web') {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ 
            audio: {
              channelCount: 1,
              sampleRate: 44100,
              sampleSize: 16,
              echoCancellation: true,
              noiseSuppression: true,
            } 
          });
          
          // Keep the stream active for recording
          return stream;
        } catch (err) {
          throw new Error('Mikrofon erişimi sağlanamadı. Lütfen tarayıcı izinlerini kontrol edin.');
        }
      } else {
        const { status } = await Audio.requestPermissionsAsync();
        if (status !== 'granted') {
          throw new Error('Mikrofon izni verilmedi');
        }
        
        await Audio.setAudioModeAsync({
          allowsRecordingIOS: true,
          playsInSilentModeIOS: true,
        });
      }

      const { recording } = await Audio.Recording.createAsync(
        Platform.select({
          web: {
            android: Audio.RecordingOptionsPresets.HIGH_QUALITY.android,
            ios: Audio.RecordingOptionsPresets.HIGH_QUALITY.ios,
            web: {
              mimeType: 'audio/webm',
              sampleRate: 44100,
              channelCount: 1,
              bitsPerSecond: 128000,
            },
          },
          default: Audio.RecordingOptionsPresets.HIGH_QUALITY,
        })
      );

      setRecording(recording);
      setIsRecording(true);
    } catch (err) {
      console.error('Recording error:', err);
      setError(err instanceof Error ? err.message : 'Kayıt başlatılamadı');
      setIsRecording(false);
    }
  }

  async function stopRecording(): Promise<string | null> {
    if (!recording) return null;

    try {
      setError(null);
      await recording.stopAndUnloadAsync();
      const uri = recording.getURI();
      setRecording(null);
      setIsRecording(false);

      if (!uri) {
        throw new Error('Kayıt URI alınamadı');
      }

      if (Platform.OS === 'web') {
        try {
          const response = await fetch(uri);
          if (!response.ok) {
            throw new Error('Ses dosyası alınamadı');
          }
          const blob = await response.blob();
          
          // Create a new blob with explicit MIME type
          const audioBlob = new Blob([blob], { type: 'audio/webm' });
          return URL.createObjectURL(audioBlob);
        } catch (err) {
          console.error('URI conversion error:', err);
          throw new Error('Ses dosyası dönüştürülürken hata oluştu');
        }
      }

      return uri;
    } catch (err) {
      console.error('Stop recording error:', err);
      setError(err instanceof Error ? err.message : 'Kayıt durdurulamadı');
      setRecording(null);
      setIsRecording(false);
      return null;
    }
  }

  return {
    isRecording,
    error,
    startRecording,
    stopRecording,
  };
}