import { View, Text, StyleSheet, TextInput, Pressable, Image } from 'react-native';
import { useState } from 'react';
import { Link, router } from 'expo-router';
import { LogIn, User } from 'lucide-react-native';
import Animated, { FadeIn, SlideInUp } from 'react-native-reanimated';

export default function LoginScreen() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (username && password) {
      router.replace('/(tabs)');
    }
  };

  return (
    <View style={styles.container}>
      <Image
        source={{ uri: 'https://images.unsplash.com/photo-1557683311-eac922347aa1?w=1600&auto=format&fit=crop&q=80' }}
        style={styles.backgroundImage}
      />

      <Animated.View 
        entering={FadeIn.delay(300)}
        style={styles.logoContainer}
      >
        <Image
          source={{ uri: 'https://images.unsplash.com/photo-1633409361618-c73427e4e206?w=400&auto=format&fit=crop&q=80' }}
          style={styles.logo}
        />
        <Text style={styles.appName}>MiraLog</Text>
        <Text style={styles.tagline}>by Mira Tech</Text>
      </Animated.View>

      <Animated.View 
        entering={SlideInUp.delay(600)}
        style={styles.formContainer}
      >
        <View style={styles.inputContainer}>
          <User size={20} color="#64748b" />
          <TextInput
            style={styles.input}
            placeholder="Kullanıcı Adı"
            value={username}
            onChangeText={setUsername}
          />
        </View>

        <View style={styles.inputContainer}>
          <LogIn size={20} color="#64748b" />
          <TextInput
            style={styles.input}
            placeholder="Şifre"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
          />
        </View>

        <Pressable 
          style={styles.loginButton}
          onPress={handleLogin}
        >
          <Text style={styles.loginButtonText}>Giriş Yap</Text>
        </Pressable>

        <Link href="/register" asChild>
          <Pressable style={styles.registerButton}>
            <Text style={styles.registerButtonText}>Hesap Oluştur</Text>
          </Pressable>
        </Link>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  backgroundImage: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    opacity: 0.1,
  },
  logoContainer: {
    alignItems: 'center',
    marginTop: '20%',
    marginBottom: 48,
  },
  logo: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 24,
  },
  appName: {
    fontFamily: 'Inter-Bold',
    fontSize: 32,
    color: '#0891b2',
    marginBottom: 8,
  },
  tagline: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#64748b',
  },
  formContainer: {
    padding: 24,
    gap: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  input: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#0f172a',
  },
  loginButton: {
    backgroundColor: '#0891b2',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  loginButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#ffffff',
  },
  registerButton: {
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#0891b2',
  },
  registerButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#0891b2',
  },
});