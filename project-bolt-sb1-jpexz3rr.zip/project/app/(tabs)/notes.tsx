import { View, Text, StyleSheet, ScrollView, Pressable, TextInput, Share as RNShare } from 'react-native';
import { Search, Filter, Clock, Tag, Mic, MoveVertical as MoreVertical, Star, Calendar, Trash2, CreditCard as Edit2, Share2, Copy, Download } from 'lucide-react-native';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'expo-router';
import { useNoteStore } from '../../lib/store/noteStore';
import ActionMenu from '../../components/ActionMenu';
import ConfirmDialog from '../../components/ConfirmDialog';
import Animated, { 
  FadeIn,
  FadeOut,
  Layout,
  SlideInRight,
  useAnimatedStyle,
  withSpring,
  useSharedValue,
} from 'react-native-reanimated';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export default function NotesScreen() {
  const { t } = useTranslation();
  const { notes, deleteNote, toggleStar } = useNoteStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<string | null>(null);
  const [showActions, setShowActions] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<'date' | 'category'>('date');
  const [selectedNote, setSelectedNote] = useState<number | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [noteToDelete, setNoteToDelete] = useState<number | null>(null);

  const scale = useSharedValue(1);

  const handlePressIn = () => {
    scale.value = withSpring(0.98);
  };

  const handlePressOut = () => {
    scale.value = withSpring(1);
  };

  const cardStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handleDeleteNote = (id: number) => {
    setNoteToDelete(id);
    setShowDeleteConfirm(true);
    setShowActions(null);
  };

  const confirmDelete = async () => {
    if (noteToDelete) {
      await deleteNote(noteToDelete);
      setShowDeleteConfirm(false);
      setNoteToDelete(null);
      setSelectedNote(null);
    }
  };

  const handleToggleStar = async (id: number) => {
    await toggleStar(id);
    setShowActions(null);
  };

  const handleShare = async (note: typeof notes[0]) => {
    try {
      await RNShare.share({
        title: note.title,
        message: `${note.title}\n\n${note.summary}\n\nKategori: ${note.category}\nTarih: ${note.date}`,
      });
    } catch (error) {
      console.error('Share error:', error);
    }
    setShowActions(null);
  };

  const handleDuplicate = async (note: typeof notes[0]) => {
    const { id, ...noteData } = note;
    await useNoteStore.getState().addNote({
      ...noteData,
      title: `${noteData.title} (Kopya)`,
      timestamp: new Date().toLocaleTimeString(),
      date: new Date().toISOString().split('T')[0],
    });
    setShowActions(null);
  };

  const handleExport = async (note: typeof notes[0]) => {
    // Dışa aktarma işlemi burada yapılacak
    // Örneğin PDF veya JSON olarak
    console.log('Export note:', note);
    setShowActions(null);
  };

  const renderNoteCard = (note: typeof notes[0], index: number) => (
    <AnimatedPressable
      key={note.id}
      style={[styles.noteCard, cardStyle]}
      onPress={() => setSelectedNote(selectedNote === note.id ? null : note.id)}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      entering={SlideInRight.delay(index * 100)}
    >
      <View style={styles.noteHeader}>
        <View style={[styles.categoryBadge, { backgroundColor: note.color }]}>
          <Tag size={12} color="#ffffff" />
          <Text style={styles.categoryText}>{note.category}</Text>
        </View>
        {note.isStarred && (
          <Star size={16} color="#eab308" fill="#eab308" />
        )}
      </View>

      <Text style={styles.noteTitle}>{note.title}</Text>
      <Text style={styles.noteSummary} numberOfLines={selectedNote === note.id ? undefined : 3}>
        {note.summary}
      </Text>

      {selectedNote === note.id && (
        <ActionMenu
          isStarred={note.isStarred}
          onEdit={() => console.log('Edit note:', note.id)}
          onShare={() => handleShare(note)}
          onDuplicate={() => handleDuplicate(note)}
          onExport={() => handleExport(note)}
          onDelete={() => handleDeleteNote(note.id)}
          onToggleStar={() => handleToggleStar(note.id)}
        />
      )}

      <View style={styles.noteFooter}>
        <View style={styles.noteInfo}>
          <Clock size={14} color="#64748b" />
          <Text style={styles.noteTimestamp}>{note.timestamp}</Text>
        </View>
        <Pressable 
          style={styles.actionButton}
          onPress={() => setShowActions(showActions === note.id ? null : note.id)}
        >
          <MoreVertical size={16} color="#64748b" />
        </Pressable>
      </View>

      {showActions === note.id && (
        <View style={styles.quickActions}>
          <Pressable 
            style={styles.quickAction}
            onPress={() => console.log('Edit note:', note.id)}
          >
            <Edit2 size={16} color="#64748b" />
          </Pressable>
          <Pressable 
            style={styles.quickAction}
            onPress={() => handleShare(note)}
          >
            <Share2 size={16} color="#64748b" />
          </Pressable>
          <Pressable 
            style={[styles.quickAction, styles.deleteAction]}
            onPress={() => handleDeleteNote(note.id)}
          >
            <Trash2 size={16} color="#dc2626" />
          </Pressable>
        </View>
      )}
    </AnimatedPressable>
  );

  return (
    <View style={styles.container}>
      <Animated.View 
        style={styles.header}
        entering={FadeIn}
        layout={Layout.springify()}
      >
        <View style={styles.searchContainer}>
          <Search size={20} color="#64748b" />
          <TextInput
            style={styles.searchInput}
            placeholder={t('common.searchPlaceholder')}
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
        <Pressable 
          style={styles.filterButton}
          onPress={() => setSortBy(sortBy === 'date' ? 'category' : 'date')}
        >
          <Filter size={20} color="#64748b" />
        </Pressable>
      </Animated.View>

      <ScrollView style={styles.notesList}>
        {notes.map((note, index) => renderNoteCard(note, index))}
      </ScrollView>

      <Link href="/record" asChild>
        <AnimatedPressable 
          style={styles.fab}
          entering={FadeIn.delay(300)}
        >
          <Mic size={24} color="#ffffff" />
        </AnimatedPressable>
      </Link>

      {showDeleteConfirm && (
        <ConfirmDialog
          title="Notu Sil"
          message="Bu notu silmek istediğinizden emin misiniz? Bu işlem geri alınamaz."
          confirmText="Sil"
          cancelText="İptal"
          onConfirm={confirmDelete}
          onCancel={() => {
            setShowDeleteConfirm(false);
            setNoteToDelete(null);
          }}
          isDestructive
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 12,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e5e5',
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f1f5f9',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#0f172a',
  },
  filterButton: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  notesList: {
    flex: 1,
    padding: 16,
  },
  noteCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  noteHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    gap: 4,
  },
  categoryText: {
    color: '#ffffff',
    fontSize: 12,
    fontFamily: 'Inter-Medium',
  },
  noteTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
    marginBottom: 4,
  },
  noteSummary: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#334155',
    lineHeight: 20,
  },
  noteFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  noteInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  noteTimestamp: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
  },
  actionButton: {
    padding: 4,
  },
  quickActions: {
    position: 'absolute',
    right: 16,
    top: 48,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 4,
    flexDirection: 'row',
    gap: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    zIndex: 1,
  },
  quickAction: {
    padding: 8,
    borderRadius: 4,
  },
  deleteAction: {
    borderLeftWidth: 1,
    borderLeftColor: '#f1f5f9',
  },
  fab: {
    position: 'absolute',
    right: 16,
    bottom: 16,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#0891b2',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
  },
});