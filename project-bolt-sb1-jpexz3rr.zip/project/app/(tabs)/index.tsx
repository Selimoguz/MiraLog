import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { Cloud, Mic, FileText, FolderOpen, TrendingUp, Clock, Users, Star } from 'lucide-react-native';
import { useTranslation } from 'react-i18next';
import { Link } from 'expo-router';
import { useState } from 'react';
import AnimatedLogo from '../../components/AnimatedLogo';
import Animated, { 
  FadeIn,
  SlideInRight,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withSequence,
  withDelay,
  withTiming,
  Easing
} from 'react-native-reanimated';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export default function DashboardScreen() {
  const { t } = useTranslation();
  const [isLogoHappy, setIsLogoHappy] = useState(false);
  const [isLogoProcessing, setIsLogoProcessing] = useState(false);

  const quickActions = [
    {
      icon: Mic,
      title: 'Yeni Kayıt',
      description: 'Sesli not kaydetmeye başlayın',
      route: '/record',
      color: '#0891b2',
    },
    {
      icon: FileText,
      title: 'Notlarım',
      description: 'Tüm notlarınızı görüntüleyin',
      route: '/notes',
      color: '#059669',
    },
    {
      icon: FolderOpen,
      title: 'Kategoriler',
      description: 'Kategori yönetimi',
      route: '/categories',
      color: '#9333ea',
    },
  ];

  const stats = [
    {
      icon: FileText,
      title: 'Toplam Not',
      value: '24',
      trend: '+3',
      color: '#0891b2',
    },
    {
      icon: Clock,
      title: 'Kayıt Süresi',
      value: '2.5s',
      trend: '+0.5s',
      color: '#059669',
    },
    {
      icon: Users,
      title: 'Katılımcılar',
      value: '12',
      trend: '+2',
      color: '#9333ea',
    },
    {
      icon: Star,
      title: 'Yıldızlı',
      value: '8',
      trend: '+1',
      color: '#eab308',
    },
  ];

  const handleLogoPress = () => {
    setIsLogoProcessing(true);
    setIsLogoHappy(true);
    
    setTimeout(() => {
      setIsLogoProcessing(false);
      setIsLogoHappy(false);
    }, 2000);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Cloud size={20} color="#0891b2" />
        <Text style={styles.syncStatus}>
          {t('common.syncStatus', { time: '2 dakika' })}
        </Text>
      </View>

      <View style={styles.welcomeSection}>
        <AnimatedLogo 
          size={100}
          isProcessing={isLogoProcessing}
          isHappy={isLogoHappy}
          onPress={handleLogoPress}
        />
        <Text style={styles.welcomeText}>{t('common.welcome')}</Text>
        <Text style={styles.welcomeSubtext}>{t('common.welcomeSubtext')}</Text>
      </View>

      <View style={styles.statsSection}>
        <Text style={styles.sectionTitle}>İstatistikler</Text>
        <View style={styles.statsGrid}>
          {stats.map((stat, index) => (
            <Animated.View
              key={stat.title}
              style={styles.statCard}
              entering={SlideInRight.delay(index * 100)}
            >
              <View style={[styles.statIconContainer, { backgroundColor: `${stat.color}15` }]}>
                <stat.icon size={18} color={stat.color} />
              </View>
              <View style={styles.statInfo}>
                <View style={styles.statHeader}>
                  <Text style={styles.statValue}>{stat.value}</Text>
                  <View style={styles.trendContainer}>
                    <TrendingUp size={10} color="#059669" />
                    <Text style={styles.trendText}>{stat.trend}</Text>
                  </View>
                </View>
                <Text style={styles.statTitle}>{stat.title}</Text>
              </View>
            </Animated.View>
          ))}
        </View>
      </View>

      <View style={styles.quickActionsSection}>
        <Text style={styles.sectionTitle}>{t('common.quickActions')}</Text>
        <View style={styles.actionsGrid}>
          {quickActions.map((action, index) => (
            <Link key={index} href={action.route} asChild>
              <Pressable 
                style={styles.actionCard}
                onPress={() => setIsLogoHappy(true)}
              >
                <View style={[styles.iconContainer, { backgroundColor: action.color }]}>
                  <action.icon size={24} color="#ffffff" />
                </View>
                <Text style={styles.actionTitle}>{action.title}</Text>
                <Text style={styles.actionDescription}>{action.description}</Text>
              </Pressable>
            </Link>
          ))}
        </View>
      </View>
      
      <View style={styles.latestNote}>
        <Text style={styles.sectionTitle}>{t('common.latestNote')}</Text>
        <Link href="/notes" asChild>
          <Pressable 
            style={styles.noteCard}
            onPress={() => setIsLogoHappy(true)}
          >
            <Text style={styles.noteTitle}>Ekip Toplantısı - Ürün İncelemesi</Text>
            <Text style={styles.noteTimestamp}>Bugün 14:30</Text>
            <Text style={styles.noteSummary}>
              Q4 yol haritası, yeni özellik öncelikleri ve yaklaşan sürüm takvimi görüşüldü. 
              Ekip, kullanıcı deneyimi iyileştirmeleri ve performans optimizasyonuna odaklanma konusunda anlaştı.
            </Text>
          </Pressable>
        </Link>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e5e5',
  },
  syncStatus: {
    marginLeft: 8,
    color: '#64748b',
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  welcomeSection: {
    padding: 20,
    alignItems: 'center',
    backgroundColor: '#ffffff',
  },
  welcomeText: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#0f172a',
    marginBottom: 4,
    marginTop: 12,
  },
  welcomeSubtext: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
    textAlign: 'center',
  },
  statsSection: {
    padding: 16,
    backgroundColor: '#ffffff',
    marginTop: 4,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  statCard: {
    flex: 1,
    minWidth: '48%',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  statIconContainer: {
    width: 32,
    height: 32,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statInfo: {
    flex: 1,
  },
  statHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 2,
  },
  statValue: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#0f172a',
  },
  statTitle: {
    fontSize: 11,
    fontFamily: 'Inter-Medium',
    color: '#64748b',
  },
  trendContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    backgroundColor: '#ecfdf5',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 4,
  },
  trendText: {
    fontSize: 10,
    fontFamily: 'Inter-Medium',
    color: '#059669',
  },
  quickActionsSection: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
    marginBottom: 12,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionCard: {
    flex: 1,
    minWidth: '48%',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  actionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
    marginBottom: 4,
  },
  actionDescription: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
    lineHeight: 16,
  },
  latestNote: {
    padding: 16,
  },
  noteCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  noteTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
    marginBottom: 4,
  },
  noteTimestamp: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
    marginBottom: 8,
  },
  noteSummary: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#334155',
    lineHeight: 20,
  },
});