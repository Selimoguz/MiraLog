import { Tabs } from 'expo-router';
import { Mic, FileText, FolderOpen, Settings } from 'lucide-react-native';
import { useTranslation } from 'react-i18next';
import { View, Text, StyleSheet } from 'react-native';
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function TabLayout() {
  const { t } = useTranslation();
  const [nickname, setNickname] = useState<string>('');

  useEffect(() => {
    loadNickname();
  }, []);

  const loadNickname = async () => {
    try {
      const savedNickname = await AsyncStorage.getItem('user_nickname');
      if (savedNickname) {
        setNickname(savedNickname);
      }
    } catch (error) {
      console.error('Error loading nickname:', error);
    }
  };

  const renderHeader = () => (
    <View style={styles.header}>
      <View style={styles.greetingContainer}>
        <Text style={styles.greeting}>Merhaba,</Text>
        <Text style={styles.nickname}>{nickname}</Text>
      </View>
    </View>
  );

  return (
    <Tabs
      screenOptions={{
        tabBarStyle: {
          backgroundColor: '#ffffff',
          borderTopColor: '#e5e5e5',
          height: 64,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarActiveTintColor: '#0891b2',
        tabBarInactiveTintColor: '#64748b',
        headerShown: true,
        headerStyle: {
          backgroundColor: '#ffffff',
        },
        headerShadowVisible: false,
        headerTitleStyle: {
          fontFamily: 'Inter-SemiBold',
          fontSize: 18,
          color: '#0f172a',
        },
        tabBarLabelStyle: {
          fontFamily: 'Inter-Medium',
          fontSize: 12,
          marginTop: 4,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Ana Sayfa',
          tabBarIcon: ({ size, color }) => <FileText size={size} color={color} />,
          header: () => renderHeader(),
        }}
      />
      <Tabs.Screen
        name="record"
        options={{
          title: 'Kayıt',
          tabBarIcon: ({ size, color }) => <Mic size={size} color={color} />,
          headerTitle: 'Yeni Kayıt',
        }}
      />
      <Tabs.Screen
        name="notes"
        options={{
          title: 'Notlar',
          tabBarIcon: ({ size, color }) => <FileText size={size} color={color} />,
          headerTitle: 'Notlarım',
        }}
      />
      <Tabs.Screen
        name="categories"
        options={{
          title: 'Kategoriler',
          tabBarIcon: ({ size, color }) => <FolderOpen size={size} color={color} />,
          headerTitle: 'Kategoriler',
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Ayarlar',
          tabBarIcon: ({ size, color }) => <Settings size={size} color={color} />,
          headerShown: false,
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e5e5',
  },
  greetingContainer: {
    flexDirection: 'column',
    gap: 2,
  },
  greeting: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#0f172a',
  },
  nickname: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#64748b',
  },
});