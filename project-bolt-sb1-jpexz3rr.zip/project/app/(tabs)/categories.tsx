import { View, Text, StyleSheet, ScrollView, Pressable, TextInput } from 'react-native';
import { FolderOpen, Plus, Search, MoveVertical as MoreVertical, Users, Lightbulb, Phone, Calendar, Tag, Star } from 'lucide-react-native';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import ActionMenu from '../../components/ActionMenu';
import ConfirmDialog from '../../components/ConfirmDialog';
import CategoryDialog from '../../components/CategoryDialog';
import Animated, {
  FadeIn,
  FadeOut,
  Layout,
  SlideInRight,
  useAnimatedStyle,
  withSpring,
  useSharedValue,
} from 'react-native-reanimated';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const INITIAL_CATEGORIES = [
  {
    id: 1,
    name: 'Toplantılar',
    description: 'Toplantı notları ve kararlar',
    icon: Users,
    color: '#0891b2',
    isStarred: true,
    count: 8,
    lastUsed: '2 saat önce',
  },
  {
    id: 2,
    name: 'Fikirler',
    description: 'Proje fikirleri ve beyin fırtınası',
    icon: Lightbulb,
    color: '#ca8a04',
    isStarred: false,
    count: 5,
    lastUsed: '4 saat önce',
  },
  {
    id: 3,
    name: 'Görüşmeler',
    description: 'Görüşme kayıtları ve özetleri',
    icon: Phone,
    color: '#059669',
    isStarred: true,
    count: 3,
    lastUsed: 'Dün',
  },
  {
    id: 4,
    name: 'Etkinlikler',
    description: 'Etkinlik planlaması ve notları',
    icon: Calendar,
    color: '#9333ea',
    isStarred: false,
    count: 2,
    lastUsed: '3 gün önce',
  },
];

export default function CategoriesScreen() {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState(INITIAL_CATEGORIES);
  const [showActions, setShowActions] = useState<number | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState<number | null>(null);
  const [showAddCategory, setShowAddCategory] = useState(false);
  const [categoryToEdit, setCategoryToEdit] = useState<typeof INITIAL_CATEGORIES[0] | null>(null);

  const handleAddCategory = () => {
    setShowAddCategory(true);
  };

  const handleSaveCategory = (data: { name: string; description: string; color: string }) => {
    if (categoryToEdit) {
      setCategories(categories.map(cat => 
        cat.id === categoryToEdit.id 
          ? { ...cat, ...data }
          : cat
      ));
      setCategoryToEdit(null);
    } else {
      const newCategory = {
        id: Date.now(),
        ...data,
        icon: FolderOpen,
        isStarred: false,
        count: 0,
        lastUsed: 'Yeni',
      };
      setCategories([...categories, newCategory]);
    }
    setShowAddCategory(false);
  };

  const handleEditCategory = (category: typeof INITIAL_CATEGORIES[0]) => {
    setCategoryToEdit(category);
    setShowAddCategory(true);
    setShowActions(null);
  };

  const handleDeleteCategory = (id: number) => {
    setCategoryToDelete(id);
    setShowDeleteConfirm(true);
    setShowActions(null);
  };

  const confirmDelete = () => {
    if (categoryToDelete) {
      setCategories(categories.filter(cat => cat.id !== categoryToDelete));
      setShowDeleteConfirm(false);
      setCategoryToDelete(null);
    }
  };

  const handleToggleStar = (id: number) => {
    setCategories(categories.map(cat =>
      cat.id === id ? { ...cat, isStarred: !cat.isStarred } : cat
    ));
    setShowActions(null);
  };

  const filteredCategories = categories.filter(category =>
    category.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    category.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const scale = useSharedValue(1);

  const handlePressIn = () => {
    scale.value = withSpring(0.98);
  };

  const handlePressOut = () => {
    scale.value = withSpring(1);
  };

  const cardStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const starredCategories = filteredCategories.filter(cat => cat.isStarred);
  const otherCategories = filteredCategories.filter(cat => !cat.isStarred);

  const renderCategoryCard = (category: typeof categories[0], index: number) => (
    <AnimatedPressable
      key={category.id}
      style={[styles.categoryCard, cardStyle]}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      entering={SlideInRight.delay(index * 100)}
      exiting={FadeOut}
      layout={Layout.springify()}
    >
      <View style={[styles.iconContainer, { backgroundColor: category.color }]}>
        <category.icon size={24} color="#ffffff" />
      </View>

      <View style={styles.categoryContent}>
        <View style={styles.titleRow}>
          <Text style={styles.categoryName}>{category.name}</Text>
          {category.isStarred && (
            <Star size={16} color="#eab308" fill="#eab308" />
          )}
        </View>

        <Text style={styles.categoryDescription} numberOfLines={2}>
          {category.description}
        </Text>

        <View style={styles.categoryMeta}>
          <View style={styles.notesCount}>
            <Tag size={12} color="#64748b" />
            <Text style={styles.countText}>
              {category.count} not
            </Text>
          </View>
          <Text style={styles.lastUsed}>{category.lastUsed}</Text>
        </View>
      </View>

      <Pressable 
        style={styles.menuButton}
        onPress={() => setShowActions(showActions === category.id ? null : category.id)}
      >
        <MoreVertical size={16} color="#64748b" />
      </Pressable>

      {showActions === category.id && (
        <ActionMenu
          isStarred={category.isStarred}
          onEdit={() => handleEditCategory(category)}
          onDelete={() => handleDeleteCategory(category.id)}
          onToggleStar={() => handleToggleStar(category.id)}
        />
      )}
    </AnimatedPressable>
  );

  return (
    <View style={styles.container}>
      <Animated.View 
        style={styles.header}
        entering={FadeIn}
        layout={Layout.springify()}
      >
        <View style={styles.searchContainer}>
          <Search size={18} color="#64748b" />
          <TextInput
            style={styles.searchInput}
            placeholder="Kategorilerde ara..."
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
        <Pressable 
          style={styles.addButton}
          onPress={handleAddCategory}
        >
          <Plus size={18} color="#ffffff" />
        </Pressable>
      </Animated.View>

      <ScrollView style={styles.categoriesList}>
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{categories.length}</Text>
            <Text style={styles.statLabel}>Toplam Kategori</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>
              {categories.reduce((sum, cat) => sum + cat.count, 0)}
            </Text>
            <Text style={styles.statLabel}>Toplam Not</Text>
          </View>
        </View>

        {starredCategories.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Yıldızlı Kategoriler</Text>
            <View style={styles.categoriesGrid}>
              {starredCategories.map((category, index) => renderCategoryCard(category, index))}
            </View>
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Tüm Kategoriler</Text>
          <View style={styles.categoriesGrid}>
            {otherCategories.map((category, index) => renderCategoryCard(category, index))}
          </View>
        </View>
      </ScrollView>

      {showDeleteConfirm && (
        <ConfirmDialog
          title="Kategoriyi Sil"
          message="Bu kategoriyi silmek istediğinizden emin misiniz? Bu işlem geri alınamaz."
          confirmText="Sil"
          cancelText="İptal"
          onConfirm={confirmDelete}
          onCancel={() => {
            setShowDeleteConfirm(false);
            setCategoryToDelete(null);
          }}
          isDestructive
        />
      )}

      {showAddCategory && (
        <CategoryDialog
          title={categoryToEdit ? 'Kategori Düzenle' : 'Yeni Kategori'}
          onClose={() => {
            setShowAddCategory(false);
            setCategoryToEdit(null);
          }}
          onSave={handleSaveCategory}
          initialData={categoryToEdit ? {
            name: categoryToEdit.name,
            description: categoryToEdit.description,
            color: categoryToEdit.color,
          } : undefined}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    gap: 8,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e5e5',
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f1f5f9',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#0f172a',
  },
  addButton: {
    width: 36,
    height: 36,
    borderRadius: 8,
    backgroundColor: '#0891b2',
    justifyContent: 'center',
    alignItems: 'center',
  },
  categoriesList: {
    flex: 1,
  },
  section: {
    marginBottom: 16,
    paddingHorizontal: 12,
  },
  sectionTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
    marginBottom: 8,
  },
  statsContainer: {
    flexDirection: 'row',
    padding: 12,
    gap: 8,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  statNumber: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#0891b2',
    marginBottom: 2,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
    textAlign: 'center',
  },
  categoriesGrid: {
    gap: 8,
  },
  categoryCard: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 12,
    flexDirection: 'row',
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  categoryContent: {
    flex: 1,
    gap: 4,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  categoryName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
  },
  categoryDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
    lineHeight: 20,
  },
  categoryMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  notesCount: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  countText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
  },
  lastUsed: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94a3b8',
  },
  menuButton: {
    padding: 4,
  },
});