import { View, Text, StyleSheet, Switch, ScrollView } from 'react-native';
import { Shield, Eye, Lock, Bell, Share2 } from 'lucide-react-native';
import { useState } from 'react';

export default function PrivacyScreen() {
  const [isProfilePublic, setIsProfilePublic] = useState(false);
  const [showEmail, setShowEmail] = useState(false);
  const [allowSharing, setAllowSharing] = useState(true);
  const [showNotifications, setShowNotifications] = useState(true);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Shield size={20} color="#7c3aed" />
          <Text style={styles.sectionTitle}>Hesap Gizliliği</Text>
        </View>
        
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Eye size={20} color="#64748b" />
            <Text style={styles.settingLabel}>Profili Herkese Açık Yap</Text>
          </View>
          <Switch
            value={isProfilePublic}
            onValueChange={setIsProfilePublic}
            trackColor={{ false: '#e5e5e5', true: '#7c3aed' }}
          />
        </View>

        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Lock size={20} color="#64748b" />
            <Text style={styles.settingLabel}>E-posta Adresini Göster</Text>
          </View>
          <Switch
            value={showEmail}
            onValueChange={setShowEmail}
            trackColor={{ false: '#e5e5e5', true: '#7c3aed' }}
          />
        </View>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Share2 size={20} color="#0891b2" />
          <Text style={styles.sectionTitle}>Paylaşım Ayarları</Text>
        </View>

        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Share2 size={20} color="#64748b" />
            <Text style={styles.settingLabel}>Not Paylaşımına İzin Ver</Text>
          </View>
          <Switch
            value={allowSharing}
            onValueChange={setAllowSharing}
            trackColor={{ false: '#e5e5e5', true: '#0891b2' }}
          />
        </View>

        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Bell size={20} color="#64748b" />
            <Text style={styles.settingLabel}>Paylaşım Bildirimleri</Text>
          </View>
          <Switch
            value={showNotifications}
            onValueChange={setShowNotifications}
            trackColor={{ false: '#e5e5e5', true: '#0891b2' }}
          />
        </View>
      </View>

      <View style={styles.infoContainer}>
        <Text style={styles.infoTitle}>Gizlilik Politikası</Text>
        <Text style={styles.infoText}>
          Verilerinizin güvenliği bizim için önemlidir. Tüm verileriniz şifrelenerek saklanır ve üçüncü taraflarla paylaşılmaz.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  section: {
    backgroundColor: '#ffffff',
    marginTop: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    marginHorizontal: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  settingLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#334155',
  },
  infoContainer: {
    margin: 16,
    padding: 16,
    backgroundColor: '#f0f9ff',
    borderRadius: 12,
  },
  infoTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0891b2',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#334155',
    lineHeight: 20,
  },
});