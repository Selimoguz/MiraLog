import { Stack } from 'expo-router';

export default function SettingsLayout() {
  return (
    <Stack screenOptions={{ headerShadowVisible: false }}>
      <Stack.Screen
        name="index"
        options={{
          title: 'Ayarlar',
        }}
      />
      <Stack.Screen
        name="profile"
        options={{
          title: 'Profil',
        }}
      />
      <Stack.Screen
        name="privacy"
        options={{
          title: 'Gizlilik Ayarları',
        }}
      />
      <Stack.Screen
        name="help"
        options={{
          title: 'Yardım',
        }}
      />
    </Stack>
  );
}