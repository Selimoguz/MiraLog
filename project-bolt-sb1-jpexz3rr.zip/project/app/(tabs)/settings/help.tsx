import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { CircleHelp, ChevronRight, Book, MessageCircle, Mail, Globe } from 'lucide-react-native';

export default function HelpScreen() {
  const helpSections = [
    {
      title: 'Başlangıç Kılavuzu',
      icon: Book,
      items: [
        'Uygulamayı Kullanmaya Başlama',
        'Ses Kaydı Oluşturma',
        'Not Düzenleme',
        'Kategoriler',
      ],
    },
    {
      title: 'Sık Sorulan Sorular',
      icon: CircleHelp,
      items: [
        'Ses Kalitesi Ayarları',
        'Veri Yedekleme',
        'Paylaşım Seçenekleri',
        'Hesap Ayarları',
      ],
    },
    {
      title: 'İletişim',
      icon: MessageCircle,
      items: [
        'Destek Talebi Oluştur',
        'Geri Bildirim Gönder',
        'Hata Bildir',
      ],
    },
  ];

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <CircleHelp size={32} color="#0891b2" />
        <Text style={styles.headerTitle}>Nasıl Yardımcı Olabiliriz?</Text>
        <Text style={styles.headerSubtitle}>
          Aşağıdaki konulardan birini seçin veya bize ulaşın
        </Text>
      </View>

      {helpSections.map((section, index) => (
        <View key={index} style={styles.section}>
          <View style={styles.sectionHeader}>
            <section.icon size={20} color="#0891b2" />
            <Text style={styles.sectionTitle}>{section.title}</Text>
          </View>

          {section.items.map((item, itemIndex) => (
            <Pressable
              key={itemIndex}
              style={styles.helpItem}
              onPress={() => {}}
            >
              <Text style={styles.helpItemText}>{item}</Text>
              <ChevronRight size={20} color="#64748b" />
            </Pressable>
          ))}
        </View>
      ))}

      <View style={styles.contactSection}>
        <Text style={styles.contactTitle}>Doğrudan İletişim</Text>
        
        <Pressable style={styles.contactButton}>
          <Mail size={20} color="#0891b2" />
          <Text style={styles.contactButtonText}>E-posta Gönder</Text>
        </Pressable>

        <Pressable style={styles.contactButton}>
          <Globe size={20} color="#0891b2" />
          <Text style={styles.contactButtonText}>Web Sitesini Ziyaret Et</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#ffffff',
    padding: 24,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e5e5',
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#0f172a',
    marginTop: 16,
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
    textAlign: 'center',
  },
  section: {
    backgroundColor: '#ffffff',
    marginTop: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    marginHorizontal: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
  },
  helpItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  helpItemText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#334155',
  },
  contactSection: {
    margin: 16,
    padding: 16,
    backgroundColor: '#ffffff',
    borderRadius: 12,
  },
  contactTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
    marginBottom: 16,
  },
  contactButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#f1f5f9',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
  },
  contactButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#0891b2',
  },
});