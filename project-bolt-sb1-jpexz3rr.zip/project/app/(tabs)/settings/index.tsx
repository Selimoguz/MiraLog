import { View, Text, StyleSheet, ScrollView, Pressable, Switch, Image } from 'react-native';
import { Cloud, Bell, Globe, Moon, Shield, ChevronRight, CircleUser as UserCircle, Trash2, CircleHelp as HelpCircle, LogOut, Smartphone, Vibrate, Volume2 } from 'lucide-react-native';
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useLanguageStore } from '../../../lib/store/languageStore';
import { useSettingsStore } from '../../../lib/store/settingsStore';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter } from 'expo-router';
import ConfirmDialog from '../../../components/ConfirmDialog';
import Animated, { FadeIn, Layout } from 'react-native-reanimated';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export default function SettingsScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const { currentLanguage, setLanguage } = useLanguageStore();
  const {
    syncEnabled,
    notificationsEnabled,
    darkModeEnabled,
    soundEnabled,
    vibrationEnabled,
    toggleSync,
    toggleNotifications,
    toggleDarkMode,
    toggleSound,
    toggleVibration,
    loadSettings,
  } = useSettingsStore();

  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [showClearDataConfirm, setShowClearDataConfirm] = useState(false);
  const [nickname, setNickname] = useState('');
  const [email, setEmail] = useState('');

  useEffect(() => {
    loadSettings();
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const [savedNickname, savedEmail] = await Promise.all([
        AsyncStorage.getItem('user_nickname'),
        AsyncStorage.getItem('user_email')
      ]);
      
      if (savedNickname) {
        setNickname(savedNickname);
      }
      if (savedEmail) {
        setEmail(savedEmail);
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    }
  };

  const handleLanguageChange = () => {
    const newLang = currentLanguage === 'tr' ? 'en' : 'tr';
    setLanguage(newLang);
  };

  const handleLogout = async () => {
    try {
      await AsyncStorage.clear();
      router.replace('/auth');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const handleClearData = async () => {
    try {
      await AsyncStorage.clear();
      setShowClearDataConfirm(false);
      router.replace('/auth');
    } catch (error) {
      console.error('Clear data error:', error);
    }
  };

  const settingsSections = [
    {
      title: t('settings.account'),
      items: [
        {
          icon: UserCircle,
          label: t('settings.profile'),
          value: nickname,
          color: '#0891b2',
          showChevron: true,
          onPress: () => router.push('/settings/profile'),
        },
      ],
    },
    {
      title: t('settings.preferences'),
      items: [
        {
          icon: Cloud,
          label: t('settings.cloudSync'),
          color: '#0891b2',
          isSwitch: true,
          value: syncEnabled,
          onValueChange: toggleSync,
        },
        {
          icon: Bell,
          label: t('settings.pushNotifications'),
          color: '#059669',
          isSwitch: true,
          value: notificationsEnabled,
          onValueChange: toggleNotifications,
        },
        {
          icon: Moon,
          label: t('settings.darkMode'),
          color: '#6366f1',
          isSwitch: true,
          value: darkModeEnabled,
          onValueChange: toggleDarkMode,
        },
      ],
    },
    {
      title: t('settings.app'),
      items: [
        {
          icon: Volume2,
          label: t('settings.sound'),
          color: '#ea580c',
          isSwitch: true,
          value: soundEnabled,
          onValueChange: toggleSound,
        },
        {
          icon: Vibrate,
          label: t('settings.vibration'),
          color: '#ea580c',
          isSwitch: true,
          value: vibrationEnabled,
          onValueChange: toggleVibration,
        },
        {
          icon: Globe,
          label: t('settings.appLanguage'),
          value: currentLanguage === 'tr' ? 'Türkçe' : 'English',
          color: '#0891b2',
          showChevron: true,
          onPress: handleLanguageChange,
        },
        {
          icon: Smartphone,
          label: t('settings.appVersion'),
          value: 'v1.0.0',
          color: '#64748b',
        },
      ],
    },
    {
      title: t('settings.security'),
      items: [
        {
          icon: Shield,
          label: t('settings.privacySettings'),
          color: '#7c3aed',
          showChevron: true,
          onPress: () => router.push('/settings/privacy'),
        },
      ],
    },
    {
      title: t('settings.support'),
      items: [
        {
          icon: HelpCircle,
          label: t('settings.help'),
          color: '#0891b2',
          showChevron: true,
          onPress: () => router.push('/settings/help'),
        },
      ],
    },
    {
      title: t('settings.dangerZone'),
      items: [
        {
          icon: Trash2,
          label: t('settings.clearData'),
          color: '#dc2626',
          showChevron: true,
          onPress: () => setShowClearDataConfirm(true),
        },
        {
          icon: LogOut,
          label: t('settings.logout'),
          color: '#dc2626',
          showChevron: true,
          onPress: () => setShowLogoutConfirm(true),
        },
      ],
    },
  ];

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image
          source={{ uri: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80' }}
          style={styles.avatar}
        />
        <View style={styles.headerInfo}>
          <Text style={styles.userName}>{nickname}</Text>
          <Text style={styles.userEmail}>{email}</Text>
        </View>
      </View>

      {settingsSections.map((section, sectionIndex) => (
        <Animated.View
          key={section.title}
          style={styles.section}
          entering={FadeIn.delay(sectionIndex * 100)}
          layout={Layout.springify()}
        >
          <Text style={styles.sectionTitle}>{section.title}</Text>
          {section.items.map((item, itemIndex) => (
            <AnimatedPressable
              key={item.label}
              style={[
                styles.settingItem,
                itemIndex === section.items.length - 1 && styles.lastSettingItem,
              ]}
              onPress={item.onPress}
              disabled={!item.onPress && !item.isSwitch}
            >
              <View style={styles.settingInfo}>
                <View style={[styles.iconContainer, { backgroundColor: `${item.color}15` }]}>
                  <item.icon size={20} color={item.color} />
                </View>
                <Text style={styles.settingLabel}>{item.label}</Text>
              </View>
              <View style={styles.settingControl}>
                {item.value && !item.isSwitch && (
                  <Text style={styles.settingValue}>{item.value}</Text>
                )}
                {item.isSwitch && (
                  <Switch
                    value={item.value}
                    onValueChange={item.onValueChange}
                    trackColor={{ false: '#e5e5e5', true: item.color }}
                  />
                )}
                {item.showChevron && (
                  <ChevronRight size={20} color="#64748b" />
                )}
              </View>
            </AnimatedPressable>
          ))}
        </Animated.View>
      ))}

      {showLogoutConfirm && (
        <ConfirmDialog
          title="Çıkış Yap"
          message="Çıkış yapmak istediğinizden emin misiniz?"
          confirmText="Çıkış Yap"
          cancelText="İptal"
          onConfirm={handleLogout}
          onCancel={() => setShowLogoutConfirm(false)}
          isDestructive
        />
      )}

      {showClearDataConfirm && (
        <ConfirmDialog
          title="Verileri Temizle"
          message="Tüm verileriniz silinecek. Bu işlem geri alınamaz. Devam etmek istiyor musunuz?"
          confirmText="Temizle"
          cancelText="İptal"
          onConfirm={handleClearData}
          onCancel={() => setShowClearDataConfirm(false)}
          isDestructive
        />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e5e5',
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 16,
  },
  headerInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#64748b',
    marginHorizontal: 16,
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#ffffff',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e5e5',
  },
  lastSettingItem: {
    borderBottomWidth: 0,
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  iconContainer: {
    width: 36,
    height: 36,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  settingLabel: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#0f172a',
  },
  settingControl: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  settingValue: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
  },
});