import { View, Text, StyleSheet, Pressable, Image, ScrollView } from 'react-native';
import { Mic, Pause, Store as Stop, Save, Trash2, Volume2, AudioWaveform as Waveform } from 'lucide-react-native';
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useAudioRecording } from '../../lib/hooks/useAudioRecording';
import { transcribeAudio } from '../../lib/whisper';
import { transcribeAndSummarize } from '../../lib/gemini';
import LoadingOverlay from '../../components/LoadingOverlay';
import ErrorMessage from '../../components/ErrorMessage';
import Animated, { 
  useAnimatedStyle, 
  withSpring, 
  withRepeat, 
  withSequence,
  withTiming,
  useSharedValue,
  Easing,
  FadeIn,
  FadeOut,
  Layout,
} from 'react-native-reanimated';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);
const AnimatedWaveform = Animated.createAnimatedComponent(Waveform);

export default function RecordScreen() {
  const { t } = useTranslation();
  const { isRecording, error: recordingError, startRecording, stopRecording } = useAudioRecording();
  const [transcription, setTranscription] = useState<string>('');
  const [summary, setSummary] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingError, setProcessingError] = useState<string | null>(null);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);

  // Animation values
  const scale = useSharedValue(1);
  const opacity = useSharedValue(1);
  const rotation = useSharedValue(0);
  const waveformScale = useSharedValue(1);
  const pulseScale = useSharedValue(1);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording && !isPaused) {
      interval = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
        setAudioLevel(Math.random() * 0.5 + 0.5);
      }, 1000);

      pulseScale.value = withRepeat(
        withSequence(
          withTiming(1.2, { duration: 1000, easing: Easing.ease }),
          withTiming(1, { duration: 1000, easing: Easing.ease })
        ),
        -1,
        true
      );
    } else {
      pulseScale.value = withSpring(1);
    }
    return () => clearInterval(interval);
  }, [isRecording, isPaused]);

  const buttonStyle = useAnimatedStyle(() => ({
    transform: [
      { scale: scale.value },
      { rotate: `${rotation.value}deg` }
    ],
    opacity: opacity.value,
  }));

  const waveformStyle = useAnimatedStyle(() => ({
    transform: [{ scale: waveformScale.value * audioLevel }],
    opacity: withSpring(isRecording ? 1 : 0.5),
  }));

  const pulseStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulseScale.value }],
    opacity: withSpring(isRecording ? 1 : 0),
  }));

  const handleRecordPress = async () => {
    if (isRecording) {
      scale.value = withSequence(
        withSpring(0.8),
        withSpring(1)
      );
      rotation.value = withTiming(0);
      waveformScale.value = withSpring(0);
      
      setIsProcessing(true);
      setProcessingError(null);
      try {
        const audioUri = await stopRecording();
        if (audioUri) {
          const transcribedText = await transcribeAudio(audioUri);
          setTranscription(transcribedText);
          
          const result = await transcribeAndSummarize(transcribedText);
          setSummary(result.summary);
        }
      } catch (err) {
        setProcessingError(err instanceof Error ? err.message : t('common.error'));
      } finally {
        setIsProcessing(false);
      }
    } else {
      scale.value = withSpring(1.1);
      rotation.value = withRepeat(
        withTiming(360, {
          duration: 2000,
          easing: Easing.linear,
        }),
        -1
      );
      waveformScale.value = withSpring(1);
      
      setTranscription('');
      setSummary('');
      setProcessingError(null);
      setRecordingDuration(0);
      await startRecording();
    }
  };

  const handleRetry = () => {
    setProcessingError(null);
    setTranscription('');
    setSummary('');
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <View style={styles.container}>
      <Image
        source={{ uri: 'https://images.unsplash.com/photo-1478737270239-2f02b77fc618?w=800&auto=format&fit=crop' }}
        style={styles.backgroundImage}
      />
      
      <Animated.View 
        style={styles.header}
        entering={FadeIn}
        layout={Layout}
      >
        <Text style={styles.title}>
          {isRecording ? t('recording.inProgress') : t('recording.ready')}
        </Text>
        <Text style={styles.duration}>{formatDuration(recordingDuration)}</Text>
      </Animated.View>

      <View style={styles.waveformContainer}>
        <Animated.View style={[styles.pulseCircle, pulseStyle]} />
        <Animated.View style={[styles.waveform, waveformStyle]}>
          <AnimatedWaveform size={240} color="#0891b2" strokeWidth={1} />
        </Animated.View>
      </View>

      <View style={styles.controlsContainer}>
        {isRecording ? (
          <>
            <AnimatedPressable
              style={[styles.controlButton, styles.secondaryButton]}
              onPress={() => setIsPaused(!isPaused)}
            >
              {isPaused ? (
                <Mic size={24} color="#64748b" />
              ) : (
                <Pause size={24} color="#64748b" />
              )}
            </AnimatedPressable>

            <AnimatedPressable 
              style={[styles.recordButton, styles.recordingButton, buttonStyle]}
              onPress={handleRecordPress}
              disabled={isProcessing}
            >
              <Stop size={32} color="#ffffff" />
            </AnimatedPressable>

            <AnimatedPressable
              style={[styles.controlButton, styles.secondaryButton]}
            >
              <Volume2 size={24} color="#64748b" />
            </AnimatedPressable>
          </>
        ) : (
          <AnimatedPressable 
            style={[styles.recordButton, buttonStyle]}
            onPress={handleRecordPress}
            disabled={isProcessing}
          >
            <Mic size={32} color="#ffffff" />
          </AnimatedPressable>
        )}
      </View>

      <ScrollView style={styles.transcriptionArea}>
        {recordingError && (
          <ErrorMessage 
            message={recordingError} 
            onRetry={handleRetry}
          />
        )}

        {processingError && (
          <ErrorMessage 
            message={processingError}
            onRetry={handleRetry}
          />
        )}

        {isProcessing ? (
          <LoadingOverlay message={t('recording.processing')} />
        ) : transcription ? (
          <Animated.View entering={FadeIn}>
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>{t('recording.transcription')}</Text>
              <Text style={styles.transcriptionText}>{transcription}</Text>
            </View>
            {summary && (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>{t('recording.summary')}</Text>
                <Text style={styles.summaryText}>{summary}</Text>
              </View>
            )}
            <View style={styles.actionButtons}>
              <Pressable style={[styles.actionButton, styles.saveButton]}>
                <Save size={20} color="#ffffff" />
                <Text style={styles.actionButtonText}>{t('recording.save')}</Text>
              </Pressable>
              <Pressable style={[styles.actionButton, styles.discardButton]}>
                <Trash2 size={20} color="#dc2626" />
                <Text style={[styles.actionButtonText, styles.discardButtonText]}>
                  {t('recording.discard')}
                </Text>
              </Pressable>
            </View>
          </Animated.View>
        ) : (
          <Animated.View 
            entering={FadeIn}
            style={styles.placeholderContainer}
          >
            <Text style={styles.placeholderText}>
              {isRecording 
                ? t('recording.listening')
                : t('recording.tapToStart')}
            </Text>
          </Animated.View>
        )}
      </ScrollView>

      <Animated.Text 
        style={styles.recordingStatus}
        entering={FadeIn}
      >
        {isProcessing 
          ? t('recording.processing')
          : isRecording 
            ? t('recording.inProgress')
            : t('recording.ready')}
      </Animated.Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  backgroundImage: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    opacity: 0.05,
  },
  header: {
    padding: 16,
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
  },
  title: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
    marginBottom: 8,
  },
  duration: {
    fontSize: 48,
    fontFamily: 'Inter-Bold',
    color: '#0891b2',
    fontVariant: ['tabular-nums'],
  },
  waveformContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 240,
    marginVertical: 24,
  },
  pulseCircle: {
    position: 'absolute',
    width: 240,
    height: 240,
    borderRadius: 120,
    backgroundColor: '#0891b2',
    opacity: 0.1,
  },
  waveform: {
    opacity: 0.5,
  },
  controlsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 24,
    marginBottom: 24,
  },
  recordButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#0891b2',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
  },
  recordingButton: {
    backgroundColor: '#dc2626',
  },
  controlButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  secondaryButton: {
    backgroundColor: '#f1f5f9',
  },
  transcriptionArea: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
    marginBottom: 12,
  },
  transcriptionText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#334155',
    lineHeight: 24,
  },
  summaryText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#0f172a',
    lineHeight: 24,
    fontStyle: 'italic',
  },
  placeholderContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  placeholderText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
    textAlign: 'center',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 24,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 12,
    gap: 8,
  },
  saveButton: {
    backgroundColor: '#0891b2',
  },
  discardButton: {
    backgroundColor: '#fee2e2',
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  actionButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#ffffff',
  },
  discardButtonText: {
    color: '#dc2626',
  },
  recordingStatus: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
    textAlign: 'center',
    padding: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
  },
});