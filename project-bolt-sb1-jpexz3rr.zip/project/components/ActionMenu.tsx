import { View, Text, StyleSheet, Pressable } from 'react-native';
import { Star, Trash2, CreditCard as Edit2, Share2, Copy, Download } from 'lucide-react-native';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';

interface ActionMenuProps {
  isStarred?: boolean;
  onEdit?: () => void;
  onShare?: () => void;
  onDuplicate?: () => void;
  onExport?: () => void;
  onDelete?: () => void;
  onToggleStar?: () => void;
}

export default function ActionMenu({
  isStarred,
  onEdit,
  onShare,
  onDuplicate,
  onExport,
  onDelete,
  onToggleStar,
}: ActionMenuProps) {
  return (
    <Animated.View 
      style={styles.container}
      entering={FadeIn}
      exiting={FadeOut}
    >
      {onEdit && (
        <Pressable style={styles.actionItem} onPress={onEdit}>
          <Edit2 size={16} color="#64748b" />
          <Text style={styles.actionText}>Düzenle</Text>
        </Pressable>
      )}

      {onShare && (
        <Pressable style={styles.actionItem} onPress={onShare}>
          <Share2 size={16} color="#64748b" />
          <Text style={styles.actionText}>Paylaş</Text>
        </Pressable>
      )}

      {onDuplicate && (
        <Pressable style={styles.actionItem} onPress={onDuplicate}>
          <Copy size={16} color="#64748b" />
          <Text style={styles.actionText}>Çoğalt</Text>
        </Pressable>
      )}

      {onExport && (
        <Pressable style={styles.actionItem} onPress={onExport}>
          <Download size={16} color="#64748b" />
          <Text style={styles.actionText}>Dışa Aktar</Text>
        </Pressable>
      )}

      {onToggleStar && (
        <Pressable style={styles.actionItem} onPress={onToggleStar}>
          <Star size={16} color="#64748b" />
          <Text style={styles.actionText}>
            {isStarred ? 'Yıldızı Kaldır' : 'Yıldızla'}
          </Text>
        </Pressable>
      )}

      {onDelete && (
        <Pressable style={[styles.actionItem, styles.deleteAction]} onPress={onDelete}>
          <Trash2 size={16} color="#dc2626" />
          <Text style={[styles.actionText, styles.deleteText]}>Sil</Text>
        </Pressable>
      )}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    right: 16,
    top: 48,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    zIndex: 1,
  },
  actionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    gap: 8,
    borderRadius: 4,
  },
  actionText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748b',
  },
  deleteAction: {
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
    marginTop: 4,
    paddingTop: 8,
  },
  deleteText: {
    color: '#dc2626',
  },
});