import { View, StyleSheet } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withSequence,
  withTiming,
  withRepeat,
  Easing,
} from 'react-native-reanimated';
import { useEffect } from 'react';

interface AnimatedLogoProps {
  size?: number;
  isProcessing?: boolean;
  isHappy?: boolean;
}

export default function AnimatedLogo({ size = 120, isProcessing = false, isHappy = false }: AnimatedLogoProps) {
  const eyeScale = useSharedValue(1);
  const eyeY = useSharedValue(0);
  const eyeX = useSharedValue(0);
  const glowOpacity = useSharedValue(0);
  const robotRotate = useSharedValue(0);
  const antennaScale = useSharedValue(1);

  useEffect(() => {
    if (isProcessing) {
      robotRotate.value = withRepeat(
        withTiming(360, {
          duration: 2000,
          easing: Easing.linear,
        }),
        -1
      );
      
      glowOpacity.value = withRepeat(
        withSequence(
          withTiming(1, { duration: 1000 }),
          withTiming(0.3, { duration: 1000 })
        ),
        -1,
        true
      );

      antennaScale.value = withRepeat(
        withSequence(
          withTiming(1.2, { duration: 500 }),
          withTiming(1, { duration: 500 })
        ),
        -1,
        true
      );
    } else {
      robotRotate.value = withSpring(0);
      glowOpacity.value = withSpring(0.3);
      antennaScale.value = withSpring(1);
    }
  }, [isProcessing]);

  useEffect(() => {
    if (isHappy) {
      eyeY.value = withSpring(-2);
      eyeScale.value = withSequence(
        withSpring(0.8),
        withSpring(1)
      );
      eyeX.value = withSequence(
        withSpring(2),
        withSpring(-2),
        withSpring(0)
      );
      glowOpacity.value = withSpring(1);
    } else {
      eyeY.value = withSpring(0);
      eyeScale.value = withSpring(1);
      eyeX.value = withSpring(0);
      glowOpacity.value = withSpring(0.3);
    }
  }, [isHappy]);

  const containerStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${robotRotate.value}deg` }],
  }));

  const eyeStyle = useAnimatedStyle(() => ({
    transform: [
      { scale: eyeScale.value },
      { translateY: eyeY.value },
      { translateX: eyeX.value }
    ],
  }));

  const glowStyle = useAnimatedStyle(() => ({
    opacity: glowOpacity.value,
  }));

  const antennaStyle = useAnimatedStyle(() => ({
    transform: [{ scale: antennaScale.value }],
  }));

  return (
    <Animated.View style={[styles.container, { width: size, height: size }, containerStyle]}>
      <View style={styles.robotHead}>
        <Animated.View style={[styles.antenna, antennaStyle]}>
          <View style={styles.antennaBall} />
          <View style={styles.antennaStick} />
        </Animated.View>
        
        <View style={styles.faceContainer}>
          <Animated.View style={[styles.eyeGlow, glowStyle]} />
          <View style={styles.eyesContainer}>
            <View style={styles.eyeWrapper}>
              <Animated.View style={[styles.eye, eyeStyle]} />
              <View style={styles.eyeHighlight} />
            </View>
            <View style={styles.eyeWrapper}>
              <Animated.View style={[styles.eye, eyeStyle]} />
              <View style={styles.eyeHighlight} />
            </View>
          </View>
        </View>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  robotHead: {
    width: '100%',
    height: '100%',
    borderRadius: 32,
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 8,
    position: 'relative',
  },
  antenna: {
    position: 'absolute',
    top: -20,
    alignItems: 'center',
  },
  antennaBall: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#0891b2',
  },
  antennaStick: {
    width: 2,
    height: 16,
    backgroundColor: '#0891b2',
    marginTop: -2,
  },
  faceContainer: {
    width: '80%',
    height: '80%',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  eyeGlow: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    borderRadius: 999,
    backgroundColor: '#0891b2',
    opacity: 0.3,
  },
  eyesContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '70%',
  },
  eyeWrapper: {
    position: 'relative',
    width: 24,
    height: 24,
  },
  eye: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#0f172a',
  },
  eyeHighlight: {
    position: 'absolute',
    top: 4,
    left: 4,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#ffffff',
    opacity: 0.8,
  },
});