import { View, Text, StyleSheet } from 'react-native';
import { Calendar } from 'lucide-react-native';
import { useCalendarStore } from '../lib/store/calendarStore';
import { useGoogleCalendar } from '../lib/hooks/useGoogleCalendar';
import { format } from 'date-fns';

interface TaskExtractorProps {
  noteContent: string;
  noteId: string;
}

export default function TaskExtractor({ noteContent, noteId }: TaskExtractorProps) {
  const { addEvent } = useCalendarStore();
  const { createEvent } = useGoogleCalendar();

  // Simple task extraction logic - looks for lines starting with "- [ ]" or "TODO:"
  const extractTasks = (content: string) => {
    const tasks: string[] = [];
    const lines = content.split('\n');

    lines.forEach(line => {
      if (line.trim().startsWith('- [ ]') || line.trim().startsWith('TODO:')) {
        tasks.push(line.trim().replace('- [ ]', '').replace('TODO:', '').trim());
      }
    });

    return tasks;
  };

  const handleCreateEvent = async (task: string) => {
    const event = {
      id: Date.now().toString(),
      title: task,
      description: `Task from note: ${noteId}`,
      startDate: format(new Date(), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      endDate: format(new Date(Date.now() + 3600000), 'yyyy-MM-dd\'T\'HH:mm:ss'),
      noteId,
      attendees: [],
      isCompleted: false,
    };

    await addEvent(event);
    await createEvent({
      summary: task,
      description: `Task from MiraLog note: ${noteId}`,
      start: {
        dateTime: event.startDate,
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
      end: {
        dateTime: event.endDate,
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
    });
  };

  const tasks = extractTasks(noteContent);

  if (tasks.length === 0) return null;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Calendar size={16} color="#0891b2" />
        <Text style={styles.title}>Extracted Tasks</Text>
      </View>
      
      {tasks.map((task, index) => (
        <View key={index} style={styles.taskItem}>
          <Text style={styles.taskText}>{task}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 16,
    padding: 16,
    backgroundColor: '#f0f9ff',
    borderRadius: 8,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  title: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#0891b2',
  },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    gap: 8,
  },
  taskText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#334155',
  },
});