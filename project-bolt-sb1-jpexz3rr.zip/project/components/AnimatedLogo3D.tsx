import { View, StyleSheet, Pressable } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withSequence,
  withTiming,
  withRepeat,
  Easing,
} from 'react-native-reanimated';
import { useEffect } from 'react';

interface AnimatedLogo3DProps {
  size?: number;
  isProcessing?: boolean;
  isHappy?: boolean;
  onPress?: () => void;
}

export default function AnimatedLogo3D({ 
  size = 120, 
  isProcessing = false, 
  isHappy = false,
  onPress
}: AnimatedLogo3DProps) {
  const rotateX = useSharedValue('0deg');
  const rotateY = useSharedValue('0deg');
  const scale = useSharedValue(1);
  const translateZ = useSharedValue('0px');
  const glowOpacity = useSharedValue(0.3);
  const eyeScale = useSharedValue(1);

  useEffect(() => {
    if (isProcessing) {
      rotateY.value = withRepeat(
        withTiming('360deg', {
          duration: 2000,
          easing: Easing.linear,
        }),
        -1
      );
      
      translateZ.value = withRepeat(
        withSequence(
          withTiming('20px', { duration: 1000 }),
          withTiming('0px', { duration: 1000 })
        ),
        -1,
        true
      );

      glowOpacity.value = withRepeat(
        withSequence(
          withTiming(1, { duration: 500 }),
          withTiming(0.3, { duration: 500 })
        ),
        -1,
        true
      );
    } else {
      rotateY.value = withSpring('0deg');
      translateZ.value = withSpring('0px');
      glowOpacity.value = withSpring(0.3);
    }
  }, [isProcessing]);

  useEffect(() => {
    if (isHappy) {
      scale.value = withSequence(
        withSpring(1.1),
        withSpring(1)
      );
      eyeScale.value = withSequence(
        withSpring(0.8),
        withSpring(1.2),
        withSpring(1)
      );
      glowOpacity.value = withSpring(0.8);
    } else {
      scale.value = withSpring(1);
      eyeScale.value = withSpring(1);
      glowOpacity.value = withSpring(0.3);
    }
  }, [isHappy]);

  const containerStyle = useAnimatedStyle(() => ({
    transform: [
      { perspective: 800 },
      { rotateX: rotateX.value },
      { rotateY: rotateY.value },
      { scale: scale.value },
      { translateZ: translateZ.value }
    ],
  }));

  const faceStyle = useAnimatedStyle(() => ({
    opacity: glowOpacity.value,
  }));

  const eyeStyle = useAnimatedStyle(() => ({
    transform: [{ scale: eyeScale.value }],
  }));

  return (
    <Pressable onPress={onPress}>
      <Animated.View style={[styles.container, { width: size, height: size }, containerStyle]}>
        <View style={styles.robotBody}>
          {/* Front Face */}
          <Animated.View style={[styles.face, styles.frontFace, faceStyle]}>
            <View style={styles.eyesContainer}>
              <Animated.View style={[styles.eye, eyeStyle]}>
                <View style={styles.eyeInner}>
                  <View style={styles.eyeHighlight} />
                </View>
              </Animated.View>
              <Animated.View style={[styles.eye, eyeStyle]}>
                <View style={styles.eyeInner}>
                  <View style={styles.eyeHighlight} />
                </View>
              </Animated.View>
            </View>
          </Animated.View>

          {/* Top Face */}
          <View style={[styles.face, styles.topFace]}>
            <View style={styles.antenna}>
              <View style={styles.antennaBall} />
            </View>
          </View>

          {/* Side Faces */}
          <View style={[styles.face, styles.rightFace]} />
          <View style={[styles.face, styles.leftFace]} />
          <View style={[styles.face, styles.bottomFace]} />
          <View style={[styles.face, styles.backFace]} />
        </View>
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  robotBody: {
    width: '100%',
    height: '100%',
    position: 'relative',
    transform: [{ perspective: 800 }],
  },
  face: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    backgroundColor: '#ffffff',
    borderRadius: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  frontFace: {
    transform: [{ translateZ: '30px' }],
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  topFace: {
    transform: [{ rotateX: '-90deg' }, { translateY: -30 }],
    height: 60,
    backgroundColor: '#f1f5f9',
  },
  rightFace: {
    transform: [{ rotateY: '90deg' }, { translateX: 30 }],
    width: 60,
    backgroundColor: '#f1f5f9',
  },
  leftFace: {
    transform: [{ rotateY: '-90deg' }, { translateX: -30 }],
    width: 60,
    backgroundColor: '#f1f5f9',
  },
  bottomFace: {
    transform: [{ rotateX: '90deg' }, { translateY: 30 }],
    height: 60,
    backgroundColor: '#f1f5f9',
  },
  backFace: {
    transform: [{ rotateY: '180deg' }, { translateZ: '-30px' }],
    backgroundColor: '#f1f5f9',
  },
  eyesContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  eye: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#0891b2',
    padding: 2,
  },
  eyeInner: {
    flex: 1,
    backgroundColor: '#0f172a',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  eyeHighlight: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#ffffff',
    opacity: 0.8,
  },
  antenna: {
    position: 'absolute',
    top: -16,
    left: '50%',
    transform: [{ translateX: -6 }],
  },
  antennaBall: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#0891b2',
  },
});