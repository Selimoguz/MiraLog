import { View, Text, StyleSheet, Pressable } from 'react-native';
import { TriangleAlert as AlertTriangle } from 'lucide-react-native';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';

interface ConfirmDialogProps {
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  onConfirm: () => void;
  onCancel: () => void;
  isDestructive?: boolean;
}

export default function ConfirmDialog({
  title,
  message,
  confirmText = 'Onayla',
  cancelText = 'İptal',
  onConfirm,
  onCancel,
  isDestructive = false,
}: ConfirmDialogProps) {
  return (
    <Animated.View 
      style={styles.overlay}
      entering={FadeIn}
      exiting={FadeOut}
    >
      <View style={styles.container}>
        <View style={styles.header}>
          <AlertTriangle size={24} color={isDestructive ? '#dc2626' : '#0891b2'} />
          <Text style={styles.title}>{title}</Text>
        </View>
        
        <Text style={styles.message}>{message}</Text>
        
        <View style={styles.actions}>
          <Pressable 
            style={[styles.button, styles.cancelButton]} 
            onPress={onCancel}
          >
            <Text style={styles.cancelText}>{cancelText}</Text>
          </Pressable>
          
          <Pressable 
            style={[
              styles.button, 
              styles.confirmButton,
              isDestructive && styles.destructiveButton
            ]} 
            onPress={onConfirm}
          >
            <Text style={[
              styles.confirmText,
              isDestructive && styles.destructiveText
            ]}>
              {confirmText}
            </Text>
          </Pressable>
        </View>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  container: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 24,
    width: '90%',
    maxWidth: 400,
    gap: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  title: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#0f172a',
  },
  message: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#334155',
    lineHeight: 20,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 8,
  },
  button: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    minWidth: 80,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#f1f5f9',
  },
  confirmButton: {
    backgroundColor: '#0891b2',
  },
  destructiveButton: {
    backgroundColor: '#dc2626',
  },
  cancelText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748b',
  },
  confirmText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#ffffff',
  },
  destructiveText: {
    color: '#ffffff',
  },
});