import { View, Text, Pressable, StyleSheet } from 'react-native';
import { ChevronDown, Users } from 'lucide-react-native';
import { useState } from 'react';
import { useTeamStore } from '../lib/store/teamStore';
import Animated, { FadeIn, FadeOut, Layout } from 'react-native-reanimated';

export default function TeamSelector() {
  const { teams, currentTeam, switchTeam } = useTeamStore();
  const [isOpen, setIsOpen] = useState(false);

  const handleTeamSelect = (teamId: string) => {
    switchTeam(teamId);
    setIsOpen(false);
  };

  return (
    <View style={styles.container}>
      <Pressable 
        style={styles.selector}
        onPress={() => setIsOpen(!isOpen)}
      >
        <Users size={20} color="#0891b2" />
        <Text style={styles.teamName}>
          {currentTeam?.name || 'Personal'}
        </Text>
        <ChevronDown size={16} color="#64748b" />
      </Pressable>

      {isOpen && (
        <Animated.View 
          entering={FadeIn}
          exiting={FadeOut}
          layout={Layout}
          style={styles.dropdown}
        >
          {teams.map(team => (
            <Pressable
              key={team.id}
              style={[
                styles.teamOption,
                currentTeam?.id === team.id && styles.selectedTeam
              ]}
              onPress={() => handleTeamSelect(team.id)}
            >
              <Text style={[
                styles.teamOptionText,
                currentTeam?.id === team.id && styles.selectedTeamText
              ]}>
                {team.name}
              </Text>
            </Pressable>
          ))}
        </Animated.View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'relative',
  },
  selector: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#f0f9ff',
  },
  teamName: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#0f172a',
  },
  dropdown: {
    position: 'absolute',
    top: '100%',
    left: 0,
    right: 0,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    marginTop: 4,
    padding: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  teamOption: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 4,
  },
  selectedTeam: {
    backgroundColor: '#f0f9ff',
  },
  teamOptionText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#0f172a',
  },
  selectedTeamText: {
    fontFamily: 'Inter-Medium',
    color: '#0891b2',
  },
});